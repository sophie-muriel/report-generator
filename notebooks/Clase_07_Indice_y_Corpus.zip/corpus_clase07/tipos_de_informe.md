# Guía de tipos de informe

## Informe ejecutivo

El informe ejecutivo está dirigido a la dirección y resume los indicadores clave del negocio en un periodo cerrado.  Su estructura tiene cuatro partes: contexto y periodo, indicadores principales, conclusiones y una sección de datos ausentes y riesgos. Cada indicador debe citar el código de la fuente de la que proviene.

Si el periodo solicitado todavía no ha cerrado, el borrador se redacta igual, pero la sección de contexto debe advertir que las cifras son parciales.


## Informe técnico

El informe técnico describe el comportamiento del sistema durante un periodo observado. Las métricas habituales son el uso de CPU, la latencia p95, la disponibilidad y los errores 5xx. El informe presenta las métricas tal como las entrega la fuente; el prototipo no recalcula promedios ni percentiles.
