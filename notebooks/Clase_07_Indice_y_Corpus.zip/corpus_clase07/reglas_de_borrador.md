# Reglas de redacción de borradores

## Datos ausentes e incompletos

Cada métrica solicitada se contrasta con las métricas disponibles en la fuente antes de redactar. Una métrica que la fuente no ofrece se escribe como [DATO AUSENTE] en el lugar donde iría la cifra. El borrador no reemplaza ese vacío con una estimación ni con el valor de otro periodo. Si la fuente ofrece la métrica pero con registros faltantes, por ejemplo días sin datos dentro del periodo, la métrica se marca como [DATO INCOMPLETO]. En ese caso la cifra puede aparecer, pero no se presenta como verificada y se explica qué parte del periodo falta.

## Catálogo de fuentes

Las fuentes de datos se identifican con un código de la forma DS-0000, por ejemplo DS-1001. El periodo cubierto, las métricas disponibles y la fecha de última actualización de cada fuente se consultan en el catálogo mediante la herramienta consultar_fuente_datos.   Este documento explica el procedimiento y no contiene el estado ni las fechas de ninguna fuente concreta.
